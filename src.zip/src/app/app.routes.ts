import { Routes } from '@angular/router';
import { Listcustomer } from './listcustomer/listcustomer';
import { ListCustomer2 } from './listcustomer2/listcustomer2';
import { Listcustomer3 } from './listcustomer3/listcustomer3';
import { NotFound } from './not-found/not-found';
import { About } from './about/about';
import { ListProduct } from './list-product/list-product';
import { ProductDetail } from './product-detail/product-detail';
import { FakeProduct } from './fake-product/fake-product';
import { FakeProduct2 } from './fake-product2/fake-product2';
import { Bitcoin } from './bitcoin/bitcoin';


export const routes: Routes = [
    {path:"gioi-thieu",component:About},
    {path:"khach-hang-1",component:Listcustomer},
    {path:"khach-hang-2",component:ListCustomer2},
    {path:"khach-hang-3",component:Listcustomer3},
    {path:"san-pham-1", component:ListProduct},
    {path:"san-pham-1/:id",component:ProductDetail},
    {path:"ex26", component:FakeProduct},
    {path:"ex27",component:FakeProduct2},
    {path:"ex28",component:Bitcoin},
    {path:"**",component:NotFound}
];
