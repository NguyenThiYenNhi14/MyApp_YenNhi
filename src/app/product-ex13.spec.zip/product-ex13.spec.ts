import { TestBed } from '@angular/core/testing';

import { ProductEx13 } from './product-ex13';

describe('ProductEx13', () => {
  let service: ProductEx13;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProductEx13);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
