import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ProductEx13 {
  products=[{"id":"p1","name":"Coca","price":15,"image":"images/coca.jpg"},
            {"id":"p2","name":"Pepsi","price":10,"image":"images/pepsi.jpg"},
            {"id":"p3","name":"Sting","price":20,"image":"images/sting.jpg"},
  ]
  constructor() { }
  getProductsWithImages()
  {
  return this.products
  }
  getProductDetail(id:any){
  return this.products.find(x=>x.id==id)
  }
}
