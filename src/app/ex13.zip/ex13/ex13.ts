import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductEx13 } from '../product-ex13';

@Component({
  selector: 'app-ex13',
  standalone:true,
  imports: [CommonModule],
  templateUrl: './ex13.html',
  styleUrl: './ex13.css',
})
export class Ex13 {
  public products:any
constructor(pservice: ProductEx13,private router:Router){
this.products=pservice.getProductsWithImages()
}
viewDetail(f:any)
{
this.router.navigate(['service-product-image-event',f.id])
}
}